BARBER TOPOLOGY DEMO

Open index.html in a browser to preview the demo website.
The website uses online image URLs, so an internet connection is needed for the photos.

Before publishing:
- Replace the sample photos with Barber Topology's real haircut photos.
- Confirm all service names and prices.
- Add the real phone/WhatsApp number, shop address, and opening hours.
- Connect the appointment form to WhatsApp, email, or a booking service; it currently only displays a demo confirmation.
- Replace sample reviews with real customer testimonials.

The design is responsive for phones and desktop browsers.
